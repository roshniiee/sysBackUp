package paymentDetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\rosbalaj\\Desktop\\WORKSPACE_M4\\187382_SETA_Roshni_BDD\\src\\test\\resources\\PaymentDetails\\PaymentDetails.feature",dryRun=false,glue="paymentDetails")
public class TestRunner {

}
