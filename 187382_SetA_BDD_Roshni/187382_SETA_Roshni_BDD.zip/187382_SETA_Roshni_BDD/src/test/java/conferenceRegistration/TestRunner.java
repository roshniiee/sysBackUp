package conferenceRegistration;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\rosbalaj\\Desktop\\WORKSPACE_M4\\187382_SETA_Roshni_BDD\\src\\test\\resources\\ConferenceRegistration\\ConferenceRegistration.feature",dryRun=false,glue="conferenceRegistration")
public class TestRunner {

}
